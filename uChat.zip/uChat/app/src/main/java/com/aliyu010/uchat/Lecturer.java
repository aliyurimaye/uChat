package com.aliyu010.uchat;

public class Lecturer extends person {
    public Lecturer(String fName, String lName, String name, String EMail, String ID, String phoneNo, String password, String gender) {
        super(fName, lName, name, EMail, ID, phoneNo, password, gender);
    }
}
